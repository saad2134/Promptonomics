// Popup script - Displays statistics and settings
document.addEventListener('DOMContentLoaded', function() {
  loadStatistics();
  
  // Reset statistics button
  document.getElementById('reset-stats').addEventListener('click', resetStatistics);
  
  // Test data button
  document.getElementById('test-data').addEventListener('click', addTestData);
});

/**
 * Load and display statistics from storage
 */
function loadStatistics() {
  chrome.storage.local.get(['totalSavings'], function(result) {
    console.log('Loading stats from storage:', result);
    const savings = result.totalSavings || {
      co2: 0,
      water: 0,
      energy: 0,
      chars: 0,
      optimizations: 0
    };
    
    console.log('Savings to display:', savings);
    
    // Update display with proper formatting
    const co2Element = document.getElementById('total-co2');
    const waterElement = document.getElementById('total-water');
    const energyElement = document.getElementById('total-energy');
    const optimizationsElement = document.getElementById('total-optimizations');
    
    if (co2Element) co2Element.textContent = formatNumber(savings.co2) + 'g';
    if (waterElement) waterElement.textContent = formatNumber(savings.water) + 'ml';
    if (energyElement) energyElement.textContent = formatNumber(savings.energy, 6) + ' kWh';
    if (optimizationsElement) optimizationsElement.textContent = savings.optimizations;
    
    // Make the numbers visible with animation
    animateStats();
  });
}

/**
 * Reset all statistics
 */
function resetStatistics() {
  if (confirm('Are you sure you want to reset all statistics?')) {
    const emptyStats = {
      co2: 0,
      water: 0,
      energy: 0,
      chars: 0,
      optimizations: 0
    };
    
    chrome.storage.local.set({ totalSavings: emptyStats }, function() {
      loadStatistics();
      showTemporaryMessage('Statistics reset successfully!');
    });
  }
}

/**
 * Format number for display
 */
function formatNumber(num, decimals = 2) {
  const n = parseFloat(num);
  if (isNaN(n)) return '0';
  
  if (n >= 1000) {
    return (n / 1000).toFixed(1) + 'k';
  }
  
  return n.toFixed(decimals);
}

/**
 * Show temporary success message
 */
function showTemporaryMessage(message) {
  const msgDiv = document.createElement('div');
  msgDiv.style.cssText = `
    position: fixed;
    top: 10px;
    left: 50%;
    transform: translateX(-50%);
    background: #10b981;
    color: white;
    padding: 10px 20px;
    border-radius: 6px;
    font-size: 13px;
    font-weight: 500;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    z-index: 1000;
  `;
  msgDiv.textContent = message;
  document.body.appendChild(msgDiv);
  
  setTimeout(() => {
    msgDiv.remove();
  }, 2000);
}

/**
 * Animate statistics for better visibility
 */
function animateStats() {
  const statCards = document.querySelectorAll('.stat-card');
  statCards.forEach((card, index) => {
    setTimeout(() => {
      card.style.transform = 'scale(1.05)';
      card.style.boxShadow = '0 4px 20px rgba(16, 185, 129, 0.3)';
      
      setTimeout(() => {
        card.style.transform = 'scale(1)';
        card.style.boxShadow = '0 2px 8px rgba(0, 0, 0, 0.1)';
      }, 200);
    }, index * 100);
  });
}

/**
 * Test function to add sample data (for debugging)
 */
function addTestData() {
  chrome.storage.local.get(['totalSavings'], function(result) {
    const current = result.totalSavings || {
      co2: 0,
      water: 0,
      energy: 0,
      chars: 0,
      optimizations: 0
    };
    
    const testSavings = {
      co2: current.co2 + 5.2,
      water: current.water + 120,
      energy: current.energy + 0.001,
      chars: current.chars + 150,
      optimizations: current.optimizations + 3
    };
    
    chrome.storage.local.set({ totalSavings: testSavings }, function() {
      loadStatistics();
      showTemporaryMessage('Test data added! Check your dashboard.');
    });
  });
}
